<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<script>
function construct($latitude, $longitude) 
{  $latitude = deg2rad($latitude);
   $longitude = deg2rad($longitude);
   }

function getDistanceInMetersTo(POI $other) 
{ 
while dest not in result:
{
current_node = result[-1];
local_max = min(graph[current_node].values());
for node, weight in graph[current_node].items();
}
If node == local_max;
	}
   function getLatitude() 
   return $latitude;
   function getLongitude() 
   return $longitude;
$radiusOfEarth = 6371000;// Earth's radius in meters.

$diffLatitude = $getLatitude() -$latitude;
$diffLongitude = $getLongitude() - $longitude;

$a = sin($diffLatitude / 2) * sin($diffLatitude /     2) + cos($latitude) * cos($getLatitude()) * sin($diffLongitude / 2) * sin($diffLongitude / 2);
$c = 2 * asin(sqrt($a));

$distance = $radiusOfEarth * $c;
return $distance;
 }
   }
}
	
</script>
</head>

<body>
</body>
</html>