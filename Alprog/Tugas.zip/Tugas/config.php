
 <?php
$koneksi = Mysqli_connect("localhost","root","4dm1n54bo"); //mengkoneksikan dengan host
Mysqli_select_db($koneksi, "tugas"); //memilih database
?>