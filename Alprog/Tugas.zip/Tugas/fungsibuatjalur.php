<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<script>
function shortest_path(graph, source, dest){
result = [] ;
result.append(source);

while dest not in result;
{
current_node = result[-1];
local_max = min(graph[current_node].values());
for node, weight in graph[current_node].items();
}
   if weight == local_max:
   result.append(node);
return result
</script>

</head>
<body>
</body>
</html>