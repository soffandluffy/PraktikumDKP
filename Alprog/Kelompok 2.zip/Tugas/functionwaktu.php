<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<script>
function jarak ($jarak,$perjam){ 
$s=(($jarak/$perjam)*60);
$detik =($s*3600);
$waktu += 'waktu yang ditempuh'+ $detik +' detik';
Return = $waktu;
}
</script>
</head>

<body>
</body>
</html>