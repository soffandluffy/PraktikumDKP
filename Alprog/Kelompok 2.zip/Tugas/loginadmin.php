<?php
session_start();
if(!$_SESSION["username"] or !$_SESSION["password"]){
header("location:index.php"); //jika session username atau password tidak ada maka alihkan ke halaman login
}else{
//jika kedua session itu lengkap maka tampilkan halaman index ini
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="icon" type=”image/png” href= "logo.png"   />
<script language='JavaScript'>
var txt="Pencari Rute Terpendek     ";
var kecepatan=300;var segarkan=null;function bergerak() { document.title=txt;
txt=txt.substring(1,txt.length)+txt.charAt(0);
segarkan=setTimeout("bergerak()",kecepatan);}bergerak();
</script>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="viewport" content="initial-scale=1.0, user-scalable=no">
    <meta charset="utf-8">
<title>Premium Series by Free CSS Templates</title>
<script src="http://maps.google.com/maps/api/js?key=AIzaSyBJySUCJgkSTSzYotFOAZLI9EKAXBk6sGk&sensor=false"></script>
    <script>
function initialize() {
  var myLatlng = new google.maps.LatLng(-6.984175828310258,110.41000896684636);
  var mapOptions = {
    zoom: 16,
    center: myLatlng
  }
  var map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);
 
  var marker = new google.maps.Marker({
      position: myLatlng,
      map: map,
      title: ''
  });
 
  var latlng2 = new google.maps.LatLng(-6.984175828310258,110.41000896684636);
  var marker = new google.maps.Marker({    
      position: latlng2,
      map: map,
      title: 'tes'
  });
 
}
 
google.maps.event.addDomListener(window, 'load', initialize);
 
    </script>
<meta name="keywords" content="" />
<meta name="Premium Series" content="" />
<link href="default.css" rel="stylesheet" type="text/css" media="screen" /> <link rel="stylesheet" type="text/css" href="custom.css">
						
</head>
<body>
<!-- start header -->
<div id="header">
	<div id="logo">
		<h1><a href="#"><span>Sistem Informasi Geografis </span> Pencari Rute Terpendek</a></h1>
		<p></p>
	</div>
	<div id="menu">
		<ul id="main">
			<li class="current_page_item"><a href="loginadmin.php">Halaman Utama </a></li>
			<li><a href="datatempat.php">Kelola data </a></li>
			<li><a href="carirute.php">Pencarian jalur </a></li>
			<li><a href="manualpakai.php">Manual Pakai </a></li>
			<li><a href="kontak.php">kontak</a></li>
		</ul>
		<ul id="feed">
			<li><a href="dataadmin.php">Data Admin</a></li>
			<li><a href="logout.php">Logout</a></li>
		</ul>
	</div>
	
</div>
<!-- end header -->
<div id="wrapper">
	<!-- start page -->
	<div id="page">
		<div id="sidebar1" class="sidebar">
			<ul>
				<li>
					<h2>Daftar Produk </h2>
					<ul>
						<li><a href="https://www.google.co.id/?gws_rd=cr&ei=xMDKVdfNMdCkuQTc6JjwBg#q=kerajinan+kulit+kerang" target="_blank">Kerajinan Cangkang Mutiara </a></li>
						<li><a href="https://www.google.co.id/?gws_rd=cr&ei=xMDKVdfNMdCkuQTc6JjwBg#q=minyak+kayu+putih" target="_blank">Minyak Kayu Putih </a></li>
						<li><a href="https://www.google.co.id/?gws_rd=cr&ei=xMDKVdfNMdCkuQTc6JjwBg#q=ikan+asar" target="_blank">Ikan Asar </a></li>
						<li><a href="https://www.google.co.id/?gws_rd=cr&ei=xMDKVdfNMdCkuQTc6JjwBg#q=kain+tenun+maluku" target="_blank">Kain Tenun Maluku </a></li>
						<li><a href="https://www.google.co.id/?gws_rd=cr&ei=xMDKVdfNMdCkuQTc6JjwBg#q=kain+batik+corak" target="_blank">Kain Batik corak  </a></li>
						<li><a href="https://www.google.co.id/?gws_rd=cr&ei=xMDKVdfNMdCkuQTc6JjwBg#q=manisan+pala" target="_blank">Jus &amp; Manisan Buah Pala </a></li>
						<li><a href="https://www.google.co.id/?gws_rd=cr&ei=xMDKVdfNMdCkuQTc6JjwBg#q=aksesoris+besi+putih" target="_blank">Aksesoris Besi Putih </a></li>
					</ul>
				</li>
				<li>
					<h2> </h2>
					<ul>
					 
					</ul>
				</li>
			</ul>
	  </div>
		<!-- start content -->
		
		<div id="content">
			
			<div class="post">
				<h1 class="title"><a href="#">Selamat datang admin !</a></h1>
				<p class="byline"><small>Posted on , 2017 by Yudi Eko Windarto</small></p>
				<div class="entry">
				<div id="map-canvas" style="width: 510px ; height: 400px; ">
				</div>
				</div>
			</div>
		</div>
		
		<!-- end content -->
		<!-- start sidebars -->
		<!-- start sidebars -->
		<div id="sidebar2" class="sidebar">
			<ul>
			  <li>
			    <h2>Judul</h2>
			    <p class="tag"><a href="#">Greedy Distributed spanning tree routing untuk pencarian rute terpendek berbasis Sistem informasi Geografis </a><a href="#"></a></p>
			  </li>
			  <li></li>
				<li>
					<h2>Website Berelasi </h2>
					<ul>
						<li><a href="http://www.ambon.go.id/" target="_blank">Pemerintah Kota Ambon </a></li>
						<li><a href="http://www.malukuprov.go.id/" target="_blank">Pemerintah provinsi Maluku </a></li>
						<li><a href="http://www.agoda.com" target="_blank">Boking Hotel online : agoda </a></li>
						<li><a href="http://www.tripadvisor.com" target="_blank">Boking Hotel online : tripadvisor </a></li>
						<li><a href="http://www.traveloka.com" target="_blank" >Boking Hotel online : traveloka </a></li>
					</ul>
				</li>
			</ul>
	  </div>
		<!-- end sidebars -->
		<div style="clear: both;">&nbsp;</div>
	</div>
	<!-- end page -->
</div>
<div id="footer">
	<p class="copyright">&copy;&nbsp;&nbsp;2009 All Rights Reserved &nbsp;&bull;&nbsp; Design by <a href="http://www.freecsstemplates.org/">Free CSS Templates</a>.</p>
	<p class="link"><a href="#">Privacy Policy</a>&nbsp;&#8226;&nbsp;<a href="#">Terms of Use</a></p>
</div>
<div align=center>This template  downloaded form <a href='http://all-free-download.com/free-website-templates/'>free website templates</a></div></body>
</html>
<?php
}
?>