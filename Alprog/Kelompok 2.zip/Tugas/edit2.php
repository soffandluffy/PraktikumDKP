<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="icon" type=”image/png” href= "logo.png"   />
<script language='JavaScript'>
var txt="Pencari Rute Terpendek     ";
var kecepatan=300;var segarkan=null;function bergerak() { document.title=txt;
txt=txt.substring(1,txt.length)+txt.charAt(0);
segarkan=setTimeout("bergerak()",kecepatan);}bergerak();
</script>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="viewport" content="initial-scale=1.0, user-scalable=no">
    <meta charset="utf-8">
<title>Premium Series by Free CSS Templates</title>

<meta name="keywords" content="" />
<meta name="Premium Series" content="" />
<link href="default.css" rel="stylesheet" type="text/css" media="screen" /> <link rel="stylesheet" type="text/css" href="custom.css">
						
<style type="text/css">
<!--
.style3 {font-size: 16px; font-weight: bold; color: #000000; }
.style4 {color: #FFFFFF}
.style5 {color: #000000}
.style6 {font-size: 16px; font-weight: bold; color: #FFFFFF; }
.style7 {color: #FF0000}
-->
</style>
</head>
<body>
<!-- start header -->
<div id="header">
	<div id="logo">
		<h1><a href="#"><span>sistem Informasi Geografis </span> Pencari Rute Terpendek</a></h1>
		<p></p>
	</div>
	<div id="menu">
		<ul id="main">
			<li class="current_page_item"><a href="loginuser.php">Halaman Utama </a></li>
			<li><a href="#">Kelola data </a></li>
			<li><a href="#">Pencarian jalur </a></li>
			<li><a href="#">Manual Pakai </a></li>
			<li><a href="#">kontak</a></li>
		</ul>
		<ul id="feed">
			<li><a href="#">Data Admin</a></li>
			<li><a href="logout.php">Logout</a></li>
		</ul>
	</div>
	
</div>
<!-- end header -->
<div id="wrapper">
	<!-- start page -->
	<div id="page">
		<div id="sidebar1" class="sidebar">
			<ul>
				<li>
					<h2>&nbsp;</h2>
					<ul>
						
					</ul>
				</li>
				
				
		  </ul>
		</div>
		<!-- start content -->
		
		<div id="content">
			
			<div class="post">
				<h1 class="title"><a href="#">Berhasil Mengubah Data !</a></h1>
				<p class="byline"><small>Posted on April, 2015 by <a href="#">Putra casmedi </a></small></p>
			  <div class="entry">
			
 <?php

$koneksi = mysqli_connect("localhost", "root", "4dm1n54bo") or die("Gagal konek ke server.");

Mysqli_select_db("tugas") or die("Gagal membuka database.");

$ket_tmp = $_POST['ket_tmp'];

$latling = $_POST['latling'];

$nama_tmp = $_POST['nama_tmp'];

$query = mysqli_query($koneksi,"update tempat set ket_tmp='$ket_tmp',nama_tmp='$nama_tmp' where latling='$latling'");

mysqli_close($koneksi);

?>

<p>Data sudah ter-update. Silakan dicek di <a href="datatempat.php">DATA TEMPAT</a></p>

			  </div>
			</div>
		</div>
		
		<!-- end content -->
		<!-- start sidebars -->
		<!-- end sidebars -->
<div style="clear: both;">&nbsp;</div>
	</div>
	<!-- end page -->
</div>
<div id="footer">
	<p class="copyright">&copy;&nbsp;&nbsp;2015 All Rights Reserved &nbsp;&bull;&nbsp; Design by Putra Casmedi .</p>
	<p class="link">Magister Sistem Informasi Universitas Diponegoro<a href="#">.</a></p>
</div>
<div align=center></div>
</body>
</html>
